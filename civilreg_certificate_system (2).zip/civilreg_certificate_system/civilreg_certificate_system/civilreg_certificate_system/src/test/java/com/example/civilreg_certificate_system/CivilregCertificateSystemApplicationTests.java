package com.example.civilreg_certificate_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CivilregCertificateSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
