package com.example.civilreg_certificate_system.Repository;

import com.example.civilreg_certificate_system.Model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
}
