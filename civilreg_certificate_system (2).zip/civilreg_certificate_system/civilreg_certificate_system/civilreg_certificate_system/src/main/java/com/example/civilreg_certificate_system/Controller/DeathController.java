package com.example.civilreg_certificate_system.Controller;

import com.example.civilreg_certificate_system.Exception.ResourceNotFoundException;
import com.example.civilreg_certificate_system.Model.Death;
import com.example.civilreg_certificate_system.Repository.DeathRepository;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.Style;
import com.itextpdf.layout.element.Paragraph;
//import com.itextpdf.layout.properties.TextAlignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;
import java.util.UUID;
import org.springframework.web.multipart.MultipartFile;

//import javafx.scene.text.TextAlignment;



import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.UUID;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/deaths")
public class DeathController {
    @Autowired
    private DeathRepository deathRepository;

    @GetMapping("/generateId")
    public String generateId() {
        return "DEA" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6) + "TH";
    }

    @GetMapping
    public List<Death> getAllDeaths(){
        return deathRepository.findAll();
    }

    @PostMapping
    public Death createDeath(@RequestBody Death death){
        if (death.getId() == null || death.getId().isEmpty()) {
            death.setId("DEA" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6) + "TH");
        }
        return deathRepository.save(death);
    }

    @GetMapping("{id}")
    public ResponseEntity<Death> getDeathById(@PathVariable String id){
        Death death = deathRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Death not exist with id: " + id));
        return ResponseEntity.ok(death);
    }

    @PutMapping("{id}")
    public ResponseEntity<Death> updateDeath(@PathVariable String id, @RequestBody Death deathDetails){
        Death updateDeath = deathRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Death not exist with id: " + id));
        updateDeath.setFirstName(deathDetails.getFirstName());
        updateDeath.setLastName(deathDetails.getLastName());
        updateDeath.setBirthDate(deathDetails.getBirthDate());
        updateDeath.setDeathDate(deathDetails.getDeathDate());
        updateDeath.setPlaceOfDeath(deathDetails.getPlaceOfDeath());
        updateDeath.setOccupation(deathDetails.getOccupation());
        updateDeath.setDocumentPath(deathDetails.getDocumentPath());
        updateDeath.setStatus(deathDetails.getStatus());

        deathRepository.save(updateDeath);
        return ResponseEntity.ok(updateDeath);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<HttpStatus> deleteDeath(@PathVariable String id) {
        Death death = deathRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Death not exist with id: " + id));
        deathRepository.delete(death);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> downloadCertificate(@PathVariable String id) {
        Death death = deathRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Death not exist with id: " + id));

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(byteArrayOutputStream);
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document document = new Document(pdfDoc);

        // Define styles
        try {
            File fontFile = new File("/fonts/Amiri-Regular.ttf");
            PdfFont arabicFont = PdfFontFactory.createFont(fontFile.getPath(), "Identity-H", true);


            // Add content in French and Arabic using the loaded font
            document.add(new Paragraph("\t\t\t\tRÉPUBLIQUE DU TCHAD (الجمهورية التشادية)").setFont(arabicFont));
            document.add(new Paragraph("Unité - Travail - Progrès (وحدة - عمل - تقدم)").setFont(arabicFont));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("\nCertificat de décès Numéro : " + death.getId() + " (شهادة الميلاد رقم)").setFont(arabicFont));

            // Draw colored angles on the first page
            drawColoredAngles(pdfDoc);

        // Adding certificate information
            document.add(new Paragraph("Centre d'État Civil (مركز الحالة المدنية)").setFont(arabicFont));
            document.add(new Paragraph("Le ................ (التاريخ:)").setFont(arabicFont));
            document.add(new Paragraph("Nom : " + death.getFirstName() + " (الاسم)").setFont(arabicFont));
            document.add(new Paragraph("Prénom : " + death.getLastName() + " (اللقب)").setFont(arabicFont));
            document.add(new Paragraph("Né le : " + death.getBirthDate() + " (تاريخ الميلاد)").setFont(arabicFont));
            document.add(new Paragraph("Né le : " + death.getDeathDate() + " (تاريخ ميلاد الأب)").setFont(arabicFont));
            document.add(new Paragraph("Profession : " + death.getOccupation() + " (مهنة الأب)").setFont(arabicFont));
            document.add(new Paragraph("\n\n"));
            document.add(new Paragraph("L'Officier d'État Civil (ضابط الحالة المدنية)").setFont(arabicFont));



            document.close();

            byte[] pdfBytes = byteArrayOutputStream.toByteArray();

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=death_certificate_" + id + ".pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdfBytes);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    private void drawColoredAngles(PdfDocument pdfDoc) {
        Color blue = new DeviceRgb(0, 0, 255);
        Color yellow = new DeviceRgb(255, 255, 0);
        Color red = new DeviceRgb(255, 0, 0);

        PdfPage firstPage = pdfDoc.getFirstPage();
        PdfCanvas canvas = new PdfCanvas(firstPage);

        // Top-left blue angle
        canvas.saveState()
                .setFillColor(blue)
                .moveTo(0, firstPage.getPageSize().getHeight())
                .lineTo(36, firstPage.getPageSize().getHeight() - 36)
                .lineTo(36, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right blue angle
        canvas.saveState()
                .setFillColor(blue)
                .moveTo(firstPage.getPageSize().getWidth(), firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 36, firstPage.getPageSize().getHeight() - 36)
                .lineTo(firstPage.getPageSize().getWidth() - 36, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-left yellow angle
        canvas.saveState()
                .setFillColor(yellow)
                .moveTo(36, firstPage.getPageSize().getHeight())
                .lineTo(72, firstPage.getPageSize().getHeight() - 36)
                .lineTo(72, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right yellow angle
        canvas.saveState()
                .setFillColor(yellow)
                .moveTo(firstPage.getPageSize().getWidth() - 36, firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 72, firstPage.getPageSize().getHeight() - 36)
                .lineTo(firstPage.getPageSize().getWidth() - 72, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-left red angle
        canvas.saveState()
                .setFillColor(red)
                .moveTo(72, firstPage.getPageSize().getHeight())
                .lineTo(108, firstPage.getPageSize().getHeight() - 36)
                .lineTo(108, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right red angle
        canvas.saveState()
                .setFillColor(red)
                .moveTo(firstPage.getPageSize().getWidth() - 72, firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 108, firstPage.getPageSize().getHeight() - 36)
                .lineTo(firstPage.getPageSize().getWidth() - 108, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();
    }
    @PostMapping("/{id}/upload-document")
    public ResponseEntity<Death> uploadDocument(@PathVariable String id, @RequestParam("file") MultipartFile file) {
        try {
            Death death = deathRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Death not exist with id: " + id));

            // Save the file to a directory or cloud storage
            String fileName = file.getOriginalFilename();
            String filePath = "C:\\Users\\mrang\\OneDrive\\Pictures\\Screenshots" + fileName; // Adjust this path as needed
            file.transferTo(new File(filePath));

            // Update the death record with the document path
            death.setDocumentPath(filePath);
            Death updatedDeath = deathRepository.save(death);

            return ResponseEntity.ok(updatedDeath);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}

