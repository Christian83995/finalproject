//package com.example.civilreg_certificate_system.service;
//
//@Service
//public class PaymentService {
//
//    @Value("${paypack.api.key}")
//    private String apiKey;
//
//    @Value("${paypack.api.url}")
//    private String apiUrl;
//
//    private final RestTemplate restTemplate;
//
//    public PaymentService(RestTemplate restTemplate) {
//        this.restTemplate = restTemplate;
//    }
//
//    public ResponseEntity<String> processPayment(String phoneNumber, double amount) {
//        String url = UriComponentsBuilder.fromHttpUrl(apiUrl)
//                .pathSegment("pay")
//                .queryParam("phone", phoneNumber)
//                .queryParam("amount", amount)
//                .queryParam("api_key", apiKey)
//                .toUriString();
//
//        return restTemplate.postForEntity(url, null, String.class);
//    }
//}
