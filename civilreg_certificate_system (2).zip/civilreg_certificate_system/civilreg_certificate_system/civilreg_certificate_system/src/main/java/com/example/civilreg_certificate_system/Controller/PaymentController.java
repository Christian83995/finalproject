package com.example.civilreg_certificate_system.Controller;

import com.example.civilreg_certificate_system.Exception.ResourceNotFoundException;
import com.example.civilreg_certificate_system.Model.Marriage;
import com.example.civilreg_certificate_system.Model.Payment;
import com.example.civilreg_certificate_system.Repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {
    @Autowired
    private PaymentRepository paymentRepository;
    @GetMapping
    public List<Payment> getAllPayments(){
        return paymentRepository.findAll();
    }

    @PostMapping
    public Payment createPayment (@RequestBody Payment payment){
        return paymentRepository.save(payment);
    }

    @GetMapping("{id}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable long id){
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(()-> new ResourceNotFoundException("Marriage not exist with this id:" +id));
        return ResponseEntity.ok(payment);
    }
    @PutMapping("{id}")
    public ResponseEntity<Payment> updatePayment(@PathVariable long id, @RequestBody Payment paymentDetails){
        Payment updatePayment = paymentRepository.findById(id)
                .orElseThrow(()-> new ResourceNotFoundException("Marriage not exist with this id:" +id));

        updatePayment.setId(paymentDetails.getId());
        updatePayment.setPaymentId(paymentDetails.getPaymentId());
        updatePayment.setPayerId(paymentDetails.getPayerId());
        updatePayment.setPaymentStatus(paymentDetails.getPaymentStatus());
        updatePayment.setAmount(paymentDetails.getAmount());
        updatePayment.setCurrency(paymentDetails.getCurrency());
        paymentRepository.save(updatePayment);
        return ResponseEntity.ok(updatePayment);
    }
    @DeleteMapping("{id}")
    public ResponseEntity<HttpStatus> deletePayment (@PathVariable long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(()-> new ResourceNotFoundException("Payment not exist with id: "+id));
        paymentRepository.delete(payment);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
