package com.example.civilreg_certificate_system.Model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "birth")
public class Birth {
    @Id
    private String id;
    @Column(name = "first_name")
    private String firstName;
    @Column(name = "last_name")
    private String lastName;
    @Column(name = "birth_date")
    private LocalDate birthDate;
    @Column(name = "father_name")
    private String fatherName;
    @Column(name = "fbirthdate")
    private LocalDate fbirthDate;
    @Column(name = "foccupation")
    private String foccupation;
    @Column(name = "mother_name")
    private String motherName;
    @Column(name = "mbirthdate")
    private LocalDate mbirthDate;
    @Column(name = "moccupation")
    private String moccupation;
    @Column(name = "document_path")
    private String documentPath;
    @Column(name = "status")
    private String status;

    public Birth() {
        this.id = generateID();
    }

    public Birth(String id, String firstName, String lastName, LocalDate birthDate, String fatherName, LocalDate fbirthDate, String foccupation, String motherName, LocalDate mbirthDate, String moccupation, String documentPath, String status) {
        this.id = (id != null && !id.isEmpty()) ? id : generateID();
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.fatherName = fatherName;
        this.fbirthDate = fbirthDate;
        this.foccupation = foccupation;
        this.motherName = motherName;
        this.mbirthDate = mbirthDate;
        this.moccupation = moccupation;
        this.documentPath = documentPath;
        this.status = status;
    }

    private String generateID() {
        String randomUUID = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6);
        return "BIR" + randomUUID + "TH";
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public LocalDate getFbirthDate() {
        return fbirthDate;
    }

    public void setFbirthDate(LocalDate fbirthDate) {
        this.fbirthDate = fbirthDate;
    }

    public String getFoccupation() {
        return foccupation;
    }

    public void setFoccupation(String foccupation) {
        this.foccupation = foccupation;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public LocalDate getMbirthDate() {
        return mbirthDate;
    }

    public void setMbirthDate(LocalDate mbirthDate) {
        this.mbirthDate = mbirthDate;
    }

    public String getMoccupation() {
        return moccupation;
    }

    public void setMoccupation(String moccupation) {
        this.moccupation = moccupation;
    }

    public String getDocumentPath() {
        return documentPath;
    }

    public void setDocumentPath(String documentPath) {
        this.documentPath = documentPath;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
