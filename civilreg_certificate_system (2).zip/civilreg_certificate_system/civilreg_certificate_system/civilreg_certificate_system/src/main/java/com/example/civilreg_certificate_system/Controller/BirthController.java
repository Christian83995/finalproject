package com.example.civilreg_certificate_system.Controller;

import com.example.civilreg_certificate_system.Exception.ResourceNotFoundException;
import com.example.civilreg_certificate_system.Model.Birth;
import com.example.civilreg_certificate_system.Repository.BirthRepository;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import java.io.File;
import java.io.InputStream;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/births")
public class BirthController {
    @Autowired
    private BirthRepository birthRepository;

    @GetMapping("/generateId")
    public String generateId() {
        return "BIR" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6) + "TH";
    }

    @GetMapping
    public List<Birth> getAllBirths(){
        return birthRepository.findAll();
    }

    @PostMapping
    public Birth createBirth(@RequestBody Birth birth){
        if (birth.getId() == null || birth.getId().isEmpty()) {
            birth.setId("BIR" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6) + "TH");
        }
        return birthRepository.save(birth);

    }

    @GetMapping("{id}")
    public ResponseEntity<Birth> getBirthById(@PathVariable String id){
        Birth birth = birthRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Birth not exist with id: " + id));
        return ResponseEntity.ok(birth);
    }

    @PutMapping("{id}")
    public ResponseEntity<Birth> updateBirth(@PathVariable String id, @RequestBody Birth birthDetails){
        Birth updateBirth = birthRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Birth not exist with id: " + id));
        updateBirth.setFirstName(birthDetails.getFirstName());
        updateBirth.setLastName(birthDetails.getLastName());
        updateBirth.setBirthDate(birthDetails.getBirthDate());
        updateBirth.setFatherName(birthDetails.getFatherName());
        updateBirth.setFbirthDate(birthDetails.getFbirthDate());
        updateBirth.setFoccupation(birthDetails.getFoccupation());
        updateBirth.setMotherName(birthDetails.getMotherName());
        updateBirth.setMbirthDate(birthDetails.getMbirthDate());
        updateBirth.setMoccupation(birthDetails.getMoccupation());
        updateBirth.setDocumentPath(birthDetails.getDocumentPath());
        updateBirth.setStatus(birthDetails.getStatus());

        birthRepository.save(updateBirth);
        return ResponseEntity.ok(updateBirth);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<HttpStatus> deleteBirth(@PathVariable String id) {
        Birth birth = birthRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Birth not exist with id: " + id));
        birthRepository.delete(birth);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> downloadCertificate(@PathVariable String id) {
        Birth birth = birthRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Birth not exist with id: " + id));

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(byteArrayOutputStream);
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document document = new Document(pdfDoc);

        try {
            File fontFile = new File("/fonts/Amiri-Regular.ttf");
            PdfFont arabicFont = PdfFontFactory.createFont(fontFile.getPath(), "Identity-H", true);

            // Get the current date and format it
            LocalDate currentDate = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String formattedDate = currentDate.format(formatter);

            // Set smaller margins to fit content on one page
            document.setMargins(10, 10, 10, 10);


            // Add content in French and Arabic using the loaded font with a smaller font size
            document.add(new Paragraph("\t\t\tRÉPUBLIQUE DU TCHAD (الجمهورية التشادية)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Unité - Travail - Progrès (وحدة - عمل - تقدم)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("Acte de naissance Numéro : " + birth.getId() + " (شهادة الميلاد رقم)").setFont(arabicFont).setFontSize(8));

            // Draw colored angles on the first page
            drawColoredAngles(pdfDoc);

            document.add(new Paragraph("Centre d'État Civil (مركز الحالة المدنية)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Le " + formattedDate + " (التاريخ: )").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Déclare la naissance d'un enfant dont (يعلن عن ولادة طفل اسمه)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Nom : " + birth.getFirstName() + " (الاسم)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Prénom : " + birth.getLastName() + " (اللقب)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Né le : " + birth.getBirthDate() + " (تاريخ الميلاد)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("De père : " + birth.getFatherName() + " (اسم الأب)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Né le : " + birth.getFbirthDate() + " (تاريخ ميلاد الأب)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Profession : " + birth.getFoccupation() + " (مهنة الأب)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Et de mère : " + birth.getMotherName() + " (واسم الأم)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Née le : " + birth.getMbirthDate() + " (تاريخ ميلاد الأم)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("Profession : " + birth.getMoccupation() + " (مهنة الأم)").setFont(arabicFont).setFontSize(8));
            document.add(new Paragraph("L'Officier d'État Civil (ضابط الحالة المدنية)").setFont(arabicFont).setFontSize(8));

            document.close();

            byte[] pdfBytes = byteArrayOutputStream.toByteArray();

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=birth_certificate_" + id + ".pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdfBytes);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }



    private void drawColoredAngles(PdfDocument pdfDoc) {
        Color blue = new DeviceRgb(0, 0, 255);
        Color yellow = new DeviceRgb(255, 255, 0);
        Color red = new DeviceRgb(255, 0, 0);

        PdfPage firstPage = pdfDoc.getFirstPage();
        PdfCanvas canvas = new PdfCanvas(firstPage);

        // Top-left blue angle
        canvas.saveState()
                .setFillColor(blue)
                .moveTo(0, firstPage.getPageSize().getHeight())
                .lineTo(36, firstPage.getPageSize().getHeight() - 36)
                .lineTo(36, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right blue angle
        canvas.saveState()
                .setFillColor(blue)
                .moveTo(firstPage.getPageSize().getWidth(), firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 36, firstPage.getPageSize().getHeight() - 36)
                .lineTo(firstPage.getPageSize().getWidth() - 36, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-left yellow angle
        canvas.saveState()
                .setFillColor(yellow)
                .moveTo(36, firstPage.getPageSize().getHeight())
                .lineTo(72, firstPage.getPageSize().getHeight() - 36)
                .lineTo(72, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right yellow angle
        canvas.saveState()
                .setFillColor(yellow)
                .moveTo(firstPage.getPageSize().getWidth() - 36, firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 72, firstPage.getPageSize().getHeight() - 36)
                .lineTo(firstPage.getPageSize().getWidth() - 72, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-left red angle
        canvas.saveState()
                .setFillColor(red)
                .moveTo(72, firstPage.getPageSize().getHeight())
                .lineTo(108, firstPage.getPageSize().getHeight() - 36)
                .lineTo(108, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right red angle
        canvas.saveState()
                .setFillColor(red)
                .moveTo(firstPage.getPageSize().getWidth() - 72, firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 108, firstPage.getPageSize().getHeight() - 36)
                .lineTo(firstPage.getPageSize().getWidth() - 108, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();
    }
    @PatchMapping("{id}/status")
    public ResponseEntity<Birth> updateStatus(@PathVariable String id, @RequestParam String status) {
        Birth birth = birthRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Birth not exist with id: " + id));

        birth.setStatus(status);
        Birth updatedBirth = birthRepository.save(birth);

        return ResponseEntity.ok(updatedBirth);
    }
    @GetMapping("/status/{id}")
    public ResponseEntity<Map<String, String>> getBirthStatus(@PathVariable String id) {
        Birth birth = birthRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Birth not exist with id: " + id));
        Map<String, String> response = new HashMap<>();
        response.put("status", birth.getStatus());
        return ResponseEntity.ok(response);
    }


}

