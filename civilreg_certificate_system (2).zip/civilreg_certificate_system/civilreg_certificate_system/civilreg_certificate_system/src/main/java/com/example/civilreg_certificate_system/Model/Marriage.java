package com.example.civilreg_certificate_system.Model;

import jakarta.persistence.*;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "marriage")
public class Marriage {

    @Id
    private String id;

    @Column(name = "husband_first_name")
    private String husbandFirstName;

    @Column(name = "husband_last_name")
    private String husbandLastName;

    @Column(name = "wife_first_name")
    private String wifeFirstName;

    @Column(name = "wife_last_name")
    private String wifeLastName;

    @Column(name = "husband_birth_date")
    private Date husbandBirthDate;

    @Column(name = "wife_birth_date")
    private Date wifeBirthDate;

    @Column(name = "marriage_date")
    private Date marriageDate;

    @Column(name = "husband_occupation")
    private String husbandOccupation;

    @Column(name = "wife_occupation")
    private String wifeOccupation;

    @Column(name = "witness1_name")
    private String witness1Name;

    @Column(name = "witness2_name")
    private String witness2Name;

    @Column(name = "place_of_marriage")
    private String placeOfMarriage;

    @Column(name = "document_path")
    private String documentPath;

    @Column(name = "status")
    private String status;

    // Default constructor
    public Marriage()  {
        this.id = generateID();
    }

    // Parameterized constructor
    public Marriage(String id, String husbandFirstName, String husbandLastName, String wifeFirstName, String wifeLastName,
                    Date husbandBirthDate, Date wifeBirthDate, Date marriageDate, String husbandOccupation,
                    String wifeOccupation, String witness1Name, String witness2Name, String placeOfMarriage,
                    String documentPath, String status) {
        this.id = (id != null && !id.isEmpty()) ? id : generateID();
        this.husbandFirstName = husbandFirstName;
        this.husbandLastName = husbandLastName;
        this.wifeFirstName = wifeFirstName;
        this.wifeLastName = wifeLastName;
        this.husbandBirthDate = husbandBirthDate;
        this.wifeBirthDate = wifeBirthDate;
        this.marriageDate = marriageDate;
        this.husbandOccupation = husbandOccupation;
        this.wifeOccupation = wifeOccupation;
        this.witness1Name = witness1Name;
        this.witness2Name = witness2Name;
        this.placeOfMarriage = placeOfMarriage;
        this.documentPath = documentPath;
        this.status = status;
    }
    private String generateID() {
        String randomUUID = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6);
        return "MAR" + randomUUID + "RI";
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHusbandFirstName() {
        return husbandFirstName;
    }

    public void setHusbandFirstName(String husbandFirstName) {
        this.husbandFirstName = husbandFirstName;
    }

    public String getHusbandLastName() {
        return husbandLastName;
    }

    public void setHusbandLastName(String husbandLastName) {
        this.husbandLastName = husbandLastName;
    }

    public String getWifeFirstName() {
        return wifeFirstName;
    }

    public void setWifeFirstName(String wifeFirstName) {
        this.wifeFirstName = wifeFirstName;
    }

    public String getWifeLastName() {
        return wifeLastName;
    }

    public void setWifeLastName(String wifeLastName) {
        this.wifeLastName = wifeLastName;
    }

    public Date getHusbandBirthDate() {
        return husbandBirthDate;
    }

    public void setHusbandBirthDate(Date husbandBirthDate) {
        this.husbandBirthDate = husbandBirthDate;
    }

    public Date getWifeBirthDate() {
        return wifeBirthDate;
    }

    public void setWifeBirthDate(Date wifeBirthDate) {
        this.wifeBirthDate = wifeBirthDate;
    }

    public Date getMarriageDate() {
        return marriageDate;
    }

    public void setMarriageDate(Date marriageDate) {
        this.marriageDate = marriageDate;
    }

    public String getHusbandOccupation() {
        return husbandOccupation;
    }

    public void setHusbandOccupation(String husbandOccupation) {
        this.husbandOccupation = husbandOccupation;
    }

    public String getWifeOccupation() {
        return wifeOccupation;
    }

    public void setWifeOccupation(String wifeOccupation) {
        this.wifeOccupation = wifeOccupation;
    }

    public String getWitness1Name() {
        return witness1Name;
    }

    public void setWitness1Name(String witness1Name) {
        this.witness1Name = witness1Name;
    }

    public String getWitness2Name() {
        return witness2Name;
    }

    public void setWitness2Name(String witness2Name) {
        this.witness2Name = witness2Name;
    }

    public String getPlaceOfMarriage() {
        return placeOfMarriage;
    }

    public void setPlaceOfMarriage(String placeOfMarriage) {
        this.placeOfMarriage = placeOfMarriage;
    }

    public String getDocumentPath() {
        return documentPath;
    }

    public void setDocumentPath(String documentPath) {
        this.documentPath = documentPath;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
