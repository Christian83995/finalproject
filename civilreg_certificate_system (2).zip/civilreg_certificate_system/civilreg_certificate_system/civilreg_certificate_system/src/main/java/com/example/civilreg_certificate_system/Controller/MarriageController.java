package com.example.civilreg_certificate_system.Controller;

import com.example.civilreg_certificate_system.Exception.ResourceNotFoundException;
import com.example.civilreg_certificate_system.Model.Marriage;
import com.example.civilreg_certificate_system.Repository.MarriageRepository;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;
import java.util.UUID;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/marriages")
public class MarriageController {

    @Autowired
    private MarriageRepository marriageRepository;

    @GetMapping("/generateId")
    public String generateId() {
        return "MAR" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6) + "RI";
    }

    @GetMapping
    public List<Marriage> getAllMarriages(){
        return marriageRepository.findAll();
    }

    @PostMapping
    public Marriage createMarriage(@RequestBody Marriage marriage){
        if (marriage.getId() == null || marriage.getId().isEmpty()) {
            marriage.setId("MAR" + UUID.randomUUID().toString().replaceAll("-", "").substring(0, 6) + "RI");
        }
        return marriageRepository.save(marriage);
    }

    @GetMapping("{id}")
    public ResponseEntity<Marriage> getMarriageById(@PathVariable String id){
        Marriage marriage = marriageRepository.findById(id)
                .orElseThrow(()-> new ResourceNotFoundException("Marriage not exist with this id:" +id));
        return ResponseEntity.ok(marriage);
    }

    @PutMapping("{id}")
    public ResponseEntity<Marriage> updateMarriage(@PathVariable String id, @RequestBody Marriage marriageDetails){
        Marriage updateMarriage = marriageRepository.findById(id)
                .orElseThrow(()-> new ResourceNotFoundException("Marriage not exist with this id:" +id));
        updateMarriage.setHusbandFirstName(marriageDetails.getHusbandFirstName());
        updateMarriage.setHusbandLastName(marriageDetails.getHusbandLastName());
        updateMarriage.setWifeFirstName(marriageDetails.getWifeFirstName());
        updateMarriage.setWifeLastName(marriageDetails.getWifeLastName());
        updateMarriage.setHusbandBirthDate(marriageDetails.getHusbandBirthDate());
        updateMarriage.setWifeBirthDate(marriageDetails.getWifeBirthDate());
        updateMarriage.setMarriageDate(marriageDetails.getMarriageDate());
        updateMarriage.setHusbandOccupation(marriageDetails.getHusbandOccupation());
        updateMarriage.setWifeOccupation(marriageDetails.getWifeOccupation());
        updateMarriage.setWitness1Name(marriageDetails.getWitness1Name());
        updateMarriage.setWitness2Name(marriageDetails.getWitness2Name());
        updateMarriage.setPlaceOfMarriage(marriageDetails.getPlaceOfMarriage());
        updateMarriage.setDocumentPath(marriageDetails.getDocumentPath());
        updateMarriage.setStatus(marriageDetails.getStatus());

        marriageRepository.save(updateMarriage);
        return ResponseEntity.ok(updateMarriage);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteMarriage (@PathVariable String id) {
        Marriage marriage = marriageRepository.findById(id)
                .orElseThrow(()-> new ResourceNotFoundException("Marriage not exist with id: "+id));
        marriageRepository.delete(marriage);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> downloadCertificate(@PathVariable String id) {
        Marriage marriage = marriageRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Marriage not exist with id: " + id));

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(byteArrayOutputStream);
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document document = new Document(pdfDoc);

        // Adding header with colored background
        try {
            File fontFile = new File("/fonts/Amiri-Regular.ttf");
            PdfFont arabicFont = PdfFontFactory.createFont(fontFile.getPath(), "Identity-H", true);

            // Add content in French and Arabic using the loaded font
            document.add(new Paragraph("\t\t\t\tRÉPUBLIQUE DU TCHAD (الجمهورية التشادية)").setFont(arabicFont));
            document.add(new Paragraph("Unité - Travail - Progrès (وحدة - عمل - تقدم)").setFont(arabicFont));
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("\nActe de marriage numéro : " + marriage.getId() + " (شهادة الميلاد رقم)").setFont(arabicFont));

            // Draw colored angles on the first page
            drawColoredAngles(pdfDoc);

            // Ajouter les informations du certificat
            document.add(new Paragraph("Centre d'État Civil (مركز الحالة المدنية)").setFont(arabicFont));
            document.add(new Paragraph("Le ......../....../........... (التاريخ: )").setFont(arabicFont));
            document.add(new Paragraph("Déclare l'union de (يعلن عن ولادة طفل اسمه)").setFont(arabicFont));
            document.add(new Paragraph("Prénom du marié : " + marriage.getHusbandFirstName() + " (الاسم الأول للزوج)").setFont(arabicFont));
            document.add(new Paragraph("Nom du marié : " + marriage.getHusbandLastName() + " (الاسم الأخير للزوج)").setFont(arabicFont));
            document.add(new Paragraph("Prénom de l'épouse : " + marriage.getWifeFirstName() + " (الاسم الأول للزوجة)").setFont(arabicFont));
            document.add(new Paragraph("Nom de l'épouse : " + marriage.getWifeLastName() + " (الاسم الأخير للزوجة)").setFont(arabicFont));
            document.add(new Paragraph("Date du mariage : " + marriage.getMarriageDate() + " (تاريخ الزواج)").setFont(arabicFont));
            document.add(new Paragraph("Profession du marié : " + marriage.getHusbandOccupation() + " (مهنة الزوج)").setFont(arabicFont));
            document.add(new Paragraph("Profession de l'épouse : " + marriage.getWifeOccupation() + " (مهنة الزوجة)").setFont(arabicFont));
            document.add(new Paragraph("Témoin 1 : " + marriage.getWitness1Name() + " (الشاهد الأول)").setFont(arabicFont));
            document.add(new Paragraph("Témoin 2 : " + marriage.getWitness2Name() + " (الشاهد الثاني)").setFont(arabicFont));
            document.add(new Paragraph("Lieu du mariage : " + marriage.getPlaceOfMarriage() + " (مكان الزواج)").setFont(arabicFont));
            document.add(new Paragraph("\n\n"));
            document.add(new Paragraph("L'Officier d'État Civil (ضابط الحالة المدنية)").setFont(arabicFont));

            document.close();

            byte[] pdfBytes = byteArrayOutputStream.toByteArray();

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=marriage_certificate_" + id + ".pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdfBytes);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    private void drawColoredAngles(PdfDocument pdfDoc) {
        Color blue = new DeviceRgb(0, 0, 255);
        Color yellow = new DeviceRgb(255, 255, 0);
        Color red = new DeviceRgb(255, 0, 0);

        PdfPage firstPage = pdfDoc.getFirstPage();
        PdfCanvas canvas = new PdfCanvas(firstPage);

        // Top-left blue angle
        canvas.saveState()
                .setFillColor(blue)
                .moveTo(0, firstPage.getPageSize().getHeight())
                .lineTo(32, firstPage.getPageSize().getHeight() - 32)
                .lineTo(32, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right blue angle
        canvas.saveState()
                .setFillColor(blue)
                .moveTo(firstPage.getPageSize().getWidth(), firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 32, firstPage.getPageSize().getHeight() - 32)
                .lineTo(firstPage.getPageSize().getWidth() - 32, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-left yellow angle
        canvas.saveState()
                .setFillColor(yellow)
                .moveTo(32, firstPage.getPageSize().getHeight())
                .lineTo(68, firstPage.getPageSize().getHeight() - 32)
                .lineTo(68, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right yellow angle
        canvas.saveState()
                .setFillColor(yellow)
                .moveTo(firstPage.getPageSize().getWidth() - 32, firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 68, firstPage.getPageSize().getHeight() - 32)
                .lineTo(firstPage.getPageSize().getWidth() - 68, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-left red angle
        canvas.saveState()
                .setFillColor(red)
                .moveTo(68, firstPage.getPageSize().getHeight())
                .lineTo(100, firstPage.getPageSize().getHeight() - 32)
                .lineTo(100, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();

        // Top-right red angle
        canvas.saveState()
                .setFillColor(red)
                .moveTo(firstPage.getPageSize().getWidth() - 68, firstPage.getPageSize().getHeight())
                .lineTo(firstPage.getPageSize().getWidth() - 100, firstPage.getPageSize().getHeight() - 32)
                .lineTo(firstPage.getPageSize().getWidth() - 100, firstPage.getPageSize().getHeight())
                .fill()
                .restoreState();
    }
}

