const sideLinks = document.querySelectorAll(
  ".sidebar .side-menu li a:not(.logout)"
);

sideLinks.forEach((item) => {
  const li = item.parentElement;
  item.addEventListener("click", () => {
    sideLinks.forEach((i) => {
      i.parentElement.classList.remove("active");
    });
    li.classList.add("active");
  });
});

const menuBar = document.querySelector(".content nav .bx.bx-menu");
const sideBar = document.querySelector(".sidebar");

menuBar.addEventListener("click", () => {
  sideBar.classList.toggle("close");
});

window.addEventListener("resize", () => {
  if (window.innerWidth < 768) {
    sideBar.classList.add("close");
  } else {
    sideBar.classList.remove("close");
  }
  if (window.innerWidth > 576) {
    searchBtnIcon.classList.replace("bx-x", "bx-search");
    searchForm.classList.remove("show");
  }
});

const toggler = document.getElementById("theme-toggle");
const logoText = document.getElementById("logo-name");

toggler.addEventListener("change", function () {
  if (this.checked) {
    document.body.classList.add("dark");
    logoImage.src = "img/icons/White.png";
    logoText.style.color = "white";
  } else {
    document.body.classList.remove("dark");
    logoImage.src = "img/icons/logo.png";
    logoText.style.color = "var(--primary)";
  }
});

logoImage.addEventListener("click", function () {
  if (this.src.includes("White.png")) {
    this.src = "img/icons/Black.png";
  } else {
    this.src = "img/icons/White.png";
  }
});


